#!/bin/bash

# define variables
# $1 = nnet file
# $2 = property file
# $3 = summary file
# $4 = additional flags
input_net=$1
summary=$3
flags=$4
scriptdir="$(dirname "$0")"

INSTR=$scriptdir/memtime_wrapper.py
EXE=$scriptdir/planet.elf

MAX_MEM=$((8*1024*1024))
MAX_TIME=3600


function post {
    source /barrett/data/zeljic/py3.6/bin/activate
    if [ ! -f $results_file]; then
        echo "MISSING 3600 0 0" >$results_file
    fi
    python3 $scriptdir/scripts/post.py $results_file $summary
	  deactivate
	  exit
}


trap 'kill -QUIT $pid & wait $pid ; sleep 30 ; post' SIGTERM

# the working directory is where 'resources' directory is
# useful paths:
scriptdir="$(dirname "$0")"
tmpbasedir="resources/tmp"
resultdir="resources/results/solver_result"
rlvdir="resources/solvers/planet/benchmarks/twinLadder"

tmpdir=$(mktemp -d -p $tmpbasedir)
rlv_file=$tmpdir/rlv
results_file="$tmpdir/results_$(basename "$summary")"

# give permissions to scripts
chmod 777 $scriptdir/planet.elf
chmod 777 $scriptdir/memtime_wrapper.py

#fetch the .rlv network file

id=$(basename ${input_net%.nnet})

#id=$(echo $input_net | gawk  'match($0, /([0-9]+_[0-9]+)/, arr) {print arr[1]".rlv"}')
echo "cp -T $rlvdir/$prop/$id.rlv $rlv_file"
cp -T $rlvdir/$id.rlv $rlv_file

# run solvern
source /barrett/data/zeljic/py3.6/bin/activate
echo "Results file: $results_file"
$INSTR $EXE $MAX_MEM $MAX_TIME $results_file $rlv_file & pid=$!
# convert results
wait $pid
post
