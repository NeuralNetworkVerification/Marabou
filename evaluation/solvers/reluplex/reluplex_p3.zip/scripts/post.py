import sys


def convert(src_path, dest_path):
    with open(src_path, 'r') as src_file:
        in_results = src_file.readline().strip().split(',')

    result = in_results[1].strip()
    time = int(float(in_results[2].strip()) // 1000)  # convert milliseconds to second
    states = in_results[5].strip()
    avg_pivoting = 0
    summary_line = f'{result} {time} {states} {avg_pivoting}\n'

    with open(dest_path, 'w') as dest_file:
        dest_file.write(summary_line)


if __name__ == '__main__':
    src = sys.argv[1]
    dest = sys.argv[2]
    convert(src, dest)
